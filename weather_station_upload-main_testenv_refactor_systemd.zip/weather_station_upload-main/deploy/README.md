# Deployment

This folder contains a simple **systemd** deployment for Linux (Raspberry Pi, Ubuntu, Debian).

## Quick install

From the repo root:

```bash
sudo ./deploy/install.sh
```

This will:

- copy the app to `/opt/weather_station`
- install Python dependencies from `requirements.txt`
- create `/opt/weather_station/weather_services_config.yaml` from the template (if missing)
- install a systemd unit as `weather-station.service`
- enable the service at boot

## Start / stop

```bash
sudo systemctl start weather-station
sudo systemctl stop weather-station
sudo systemctl restart weather-station
```

## Logs

```bash
sudo journalctl -u weather-station -f
```

## Notes

- The unit is hardened (ProtectSystem/ProtectHome). If you need to write logs somewhere else,
  either change your YAML logging path to be inside `/opt/weather_station`, or adjust the unit.
