#!/usr/bin/env bash
set -euo pipefail

# Installs the project under /opt/weather_station and registers a systemd service.
# Run as root: sudo ./deploy/install.sh

APP_DIR="/opt/weather_station"
SERVICE_SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/systemd/weather-station.service"
SERVICE_DST="/etc/systemd/system/weather-station.service"

echo "[install] Creating user/group 'weather' if needed..."
if ! id -u weather >/dev/null 2>&1; then
  useradd --system --home "$APP_DIR" --shell /usr/sbin/nologin weather
fi

echo "[install] Creating app dir: $APP_DIR"
mkdir -p "$APP_DIR"
rsync -a --delete --exclude "test_env" --exclude ".git" --exclude ".github" "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/" "$APP_DIR/"

echo "[install] Installing python deps..."
python3 -m pip install --upgrade pip
python3 -m pip install -r "$APP_DIR/requirements.txt"

echo "[install] Ensuring config exists..."
if [[ ! -f "$APP_DIR/weather_services_config.yaml" ]]; then
  cp "$APP_DIR/weather_services_config_template.yaml" "$APP_DIR/weather_services_config.yaml"
  echo "[install] Created $APP_DIR/weather_services_config.yaml from template. EDIT THIS FILE before starting."
fi

echo "[install] Setting ownership..."
chown -R weather:weather "$APP_DIR"

echo "[install] Installing systemd unit..."
cp "$SERVICE_SRC" "$SERVICE_DST"

echo "[install] Reloading systemd + enabling service..."
systemctl daemon-reload
systemctl enable weather-station.service

echo
echo "[install] Done."
echo "Next:"
echo "  1) Edit: sudo nano $APP_DIR/weather_services_config.yaml"
echo "  2) Start: sudo systemctl start weather-station"
echo "  3) Logs:  sudo journalctl -u weather-station -f"
