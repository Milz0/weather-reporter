import os
import math
import time
import random
from datetime import datetime, timedelta

import mysql.connector


def env(name: str, default: str) -> str:
    v = os.getenv(name)
    return v if v is not None and v != "" else default


DB_HOST = env("DB_HOST", "127.0.0.1")
DB_PORT = int(env("DB_PORT", "3306"))
DB_USER = env("DB_USER", "weatheruser")
DB_PASS = env("DB_PASS", "weatherpass")
DB_NAME = env("DB_NAME", "weather")

# Live station cadence (your real station updates every minute)
INSERT_EVERY_SECONDS = int(env("INSERT_EVERY_SECONDS", "60"))
RANDOM_SEED = env("RANDOM_SEED", "")

if RANDOM_SEED:
    random.seed(int(RANDOM_SEED))


def connect_db():
    return mysql.connector.connect(
        host=DB_HOST,
        port=DB_PORT,
        user=DB_USER,
        password=DB_PASS,
        database=DB_NAME,
        autocommit=True,
        connection_timeout=10,
    )


def clamp(x: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, x))


def gaussian_noise(scale: float) -> float:
    return random.gauss(0.0, scale)


def simulate_reading(t: datetime, state: dict) -> dict:
    """Generate realistic-ish weather telemetry.

    Units match the uploader expectations:
      - temp / feels / dew: °C
      - pressure: hPa
      - wind speed / gust: km/h
      - rainfall increment: mm (per sample)
      - UV index: 0..12
      - direction: degrees 0..359
    """

    seconds_in_day = 24 * 3600
    day_phase = ((t.hour * 3600 + t.minute * 60 + t.second) / seconds_in_day) * (2.0 * math.pi)

    base_temp = state.get("base_temp", 10.0)
    diurnal = 4.0 * math.sin(day_phase - 1.0)
    temp = base_temp + diurnal + gaussian_noise(0.3)

    hum = clamp(75.0 - (temp - 10.0) * 2.0 + gaussian_noise(2.0), 20.0, 100.0)
    dew = temp - (100.0 - hum) / 5.0 + gaussian_noise(0.2)

    pressure = clamp(state.get("pressure", 1012.0) + gaussian_noise(0.15), 980.0, 1045.0)
    state["pressure"] = pressure

    wind_base = clamp(state.get("wind_base", 12.0) + gaussian_noise(0.3), 0.0, 60.0)
    state["wind_base"] = wind_base
    wind_speed = clamp(wind_base + gaussian_noise(1.0), 0.0, 80.0)
    wind_gust = clamp(wind_speed + abs(gaussian_noise(3.0)), 0.0, 120.0)

    wdir = (state.get("wdir", random.uniform(0, 360)) + gaussian_noise(6.0)) % 360.0
    state["wdir"] = wdir

    daylight = max(0.0, math.sin(day_phase))
    uv = clamp(9.0 * daylight + gaussian_noise(0.3), 0.0, 12.0)

    raining = state.get("raining", False)
    if not raining and random.random() < 0.03:
        state["raining"] = True
        state["rain_end"] = t + timedelta(minutes=random.randint(5, 25))

    if state.get("raining", False) and t >= state.get("rain_end", t):
        state["raining"] = False

    rainfall = 0.0
    if state.get("raining", False):
        # Per-sample rainfall. At 60s cadence this stays plausible.
        rainfall = clamp(random.uniform(0.0, 0.25), 0.0, 1.5)

    feels_like = temp - (wind_speed / 50.0) + gaussian_noise(0.2)

    return {
        "AIR_TEMP": round(temp, 2),
        "FEELS_LIKE": round(feels_like, 2),
        "PRESSURE_SEA": round(pressure, 2),
        "HUMIDITY": round(hum, 2),
        "DEW_POINT": round(dew, 2),
        "UV_INDEX": round(uv, 2),
        "WIND_DIRECTION": round(wdir, 1),
        "WIND_SPEED": round(wind_speed, 2),
        "WIND_GUST": round(wind_gust, 2),
        "RAINFALL": round(rainfall, 3),
    }


def insert_row(conn, reading: dict):
    sql = """
    INSERT INTO dataentry
      (CREATED, AIR_TEMP, FEELS_LIKE, PRESSURE_SEA, HUMIDITY, DEW_POINT, UV_INDEX,
       WIND_DIRECTION, WIND_SPEED, WIND_GUST, RAINFALL)
    VALUES
      (NOW(), %s, %s, %s, %s, %s, %s,
       %s, %s, %s, %s)
    """
    vals = (
        reading["AIR_TEMP"],
        reading["FEELS_LIKE"],
        reading["PRESSURE_SEA"],
        reading["HUMIDITY"],
        reading["DEW_POINT"],
        reading["UV_INDEX"],
        reading["WIND_DIRECTION"],
        reading["WIND_SPEED"],
        reading["WIND_GUST"],
        reading["RAINFALL"],
    )
    cur = conn.cursor()
    try:
        cur.execute(sql, vals)
    finally:
        cur.close()


def main():
    print(
        f"[sim] starting. db={DB_USER}@{DB_HOST}:{DB_PORT}/{DB_NAME}, every={INSERT_EVERY_SECONDS}s"
    )

    state = {
        "base_temp": 9.5 + random.uniform(-2.0, 2.0),
        "pressure": 1011.0 + random.uniform(-6.0, 6.0),
        "wind_base": 10.0 + random.uniform(-4.0, 6.0),
        "wdir": random.uniform(0, 360),
        "raining": False,
    }

    conn = None
    while True:
        try:
            if conn is None or not conn.is_connected():
                conn = connect_db()
                print("[sim] connected to db")

            t = datetime.now()
            reading = simulate_reading(t, state)
            insert_row(conn, reading)
            print(f"[sim] inserted @ {t.strftime('%H:%M:%S')} -> {reading}")
            time.sleep(INSERT_EVERY_SECONDS)

        except mysql.connector.Error as e:
            print(f"[sim] mysql error: {e} (reconnecting in 3s)")
            try:
                if conn is not None:
                    conn.close()
            except Exception:
                pass
            conn = None
            time.sleep(3)

        except Exception as e:
            print(f"[sim] unexpected error: {e}")
            time.sleep(2)


if __name__ == "__main__":
    main()
