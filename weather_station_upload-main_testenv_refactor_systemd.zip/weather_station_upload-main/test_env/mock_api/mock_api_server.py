from flask import Flask, request, jsonify
from datetime import datetime

app = Flask(__name__)


def log_request(tag: str):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print(f"[mock] {ts} {tag} {request.method} {request.path}")
    if request.query_string:
        print(f"[mock]   query: {request.query_string.decode('utf-8', errors='replace')}")
    if request.data:
        print(f"[mock]   body:  {request.data.decode('utf-8', errors='replace')}")
    print(
        "[mock]   headers subset:",
        {k: v for k, v in request.headers.items() if k.lower() in ("user-agent", "host")},
    )


@app.route("/wu", methods=["GET"])
def wu():
    log_request("wunderground")
    return "OK", 200


@app.route("/pws", methods=["GET"])
def pws():
    log_request("pwsweather")
    return "OK", 200


@app.route("/weathercloud", methods=["GET"])
def weathercloud():
    log_request("weathercloud")
    return "OK", 200


@app.route("/metoffice", methods=["GET"])
def metoffice():
    log_request("metoffice")
    return "OK", 200


@app.route("/windy", methods=["GET"])
def windy():
    log_request("windy")
    return "OK", 200


@app.route("/health", methods=["GET"])
def health():
    return jsonify({"ok": True}), 200


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8088)
