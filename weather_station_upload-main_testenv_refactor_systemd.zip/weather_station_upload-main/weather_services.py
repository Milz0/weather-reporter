#!/usr/bin/python3
"""weather_services.py

Refactored weather uploader with:
- Thread-safe DB access + reconnect
- One class per provider with a common interface
- Shared HTTP session with retries + timeouts
- Centralized data retrieval + unit conversion helpers
- Per-service scheduling loop with jitter + backoff
- Configurable rotating logs via YAML

Config file: weather_services_config.yaml (same schema as your template)
"""

from __future__ import annotations

import logging
import os
import random
import sys
import threading
import time
import traceback
from dataclasses import dataclass
from datetime import datetime
from logging.handlers import RotatingFileHandler
from typing import Any, Dict, Optional
from urllib.parse import urlencode, urlsplit, urlunsplit, parse_qsl

import mysql.connector
import requests
import yaml
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry


# ----------------------------
# Logging (configured in main)
# ----------------------------

logger = logging.getLogger("WeatherStation")


def setup_logging(cfg: Dict[str, Any]) -> None:
    """Configure console + rotating file logs based on cfg['logging'].

    Compatible with your template:
      logging:
        level: INFO
        file: /var/log/weather_station.log
        max_size: 10485760
        backup_count: 5

    If file path is not writable, falls back to ./weather_station.log
    """

    # Defaults
    log_cfg = (cfg or {}).get("logging", {}) if isinstance(cfg, dict) else {}
    level_name = str(log_cfg.get("level", "INFO")).upper()
    level = getattr(logging, level_name, logging.INFO)

    log_file = str(log_cfg.get("file", "weather_station.log"))
    max_size = int(log_cfg.get("max_size", 2_000_000))
    backup_count = int(log_cfg.get("backup_count", 5))

    fmt = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")

    logger.setLevel(level)
    logger.handlers.clear()

    console = logging.StreamHandler()
    console.setFormatter(fmt)
    logger.addHandler(console)

    # Try to create file handler (fallback to local if permission/path issues)
    file_path = log_file
    try:
        parent = os.path.dirname(file_path)
        if parent:
            os.makedirs(parent, exist_ok=True)
        # Quick write test (create if not exists)
        with open(file_path, "a", encoding="utf-8"):
            pass
    except Exception:
        file_path = "weather_station.log"

    try:
        fh = RotatingFileHandler(file_path, maxBytes=max_size, backupCount=backup_count)
        fh.setFormatter(fmt)
        logger.addHandler(fh)
    except Exception as e:
        logger.warning(f"Failed to set up file logging at '{file_path}': {e}")


# ----------------------------
# Unit conversions / helpers
# ----------------------------


def kmh_to_mph(speed_kmh: float) -> float:
    return float(speed_kmh) * 0.621371


def degc_to_degf(temp_c: float) -> float:
    return (float(temp_c) * (9.0 / 5.0)) + 32.0


def mm_to_inches(mm: float) -> float:
    return float(mm) * 0.0393701


def hpa_to_inches(hpa: float) -> float:
    return float(hpa) * 0.02953


def kmh_to_ms_times10(speed_kmh: float) -> float:
    """Weathercloud wants wind as (m/s * 10)."""
    return float(speed_kmh) * 0.277778 * 10.0


def _now_str() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def build_url_with_params(base_url: str, params: Dict[str, Any]) -> str:
    """Safely merge query parameters into a URL (preserves existing query)."""
    parts = urlsplit(base_url)
    existing = dict(parse_qsl(parts.query, keep_blank_values=True))
    merged = {**existing, **{k: v for k, v in params.items() if v is not None}}
    new_query = urlencode(merged, doseq=True)
    return urlunsplit((parts.scheme, parts.netloc, parts.path, new_query, parts.fragment))


# ----------------------------
# Data model
# ----------------------------


@dataclass(frozen=True)
class WeatherData:
    timestamp: datetime

    temperature_c: float
    feels_like_c: float
    pressure_sea_hpa: float
    humidity_pct: float
    dew_point_c: float
    uv_index: float

    wind_dir_2min_deg: float
    wind_speed_2min_kmh: float

    wind_dir_5min_deg: float
    wind_speed_5min_kmh: float
    wind_gust_5min_kmh: float

    wind_dir_10min_deg: float
    wind_speed_10min_kmh: float
    wind_gust_10min_kmh: float

    daily_rain_mm: float
    hourly_rain_mm: float


# ----------------------------
# Database access (thread-safe)
# ----------------------------


class Database:
    def __init__(self, config: Dict[str, Any]):
        self._cfg = config
        self._conn: Optional[mysql.connector.MySQLConnection] = None
        self._lock = threading.Lock()

        self.max_retries = 3
        self.retry_delay = 5  # seconds

    def _connect(self) -> mysql.connector.MySQLConnection:
        """Ensure we have a live connection (autocommit on)."""
        if self._conn is not None:
            try:
                if self._conn.is_connected():
                    return self._conn
            except Exception:
                self._conn = None

        last_err: Optional[Exception] = None
        for attempt in range(1, self.max_retries + 1):
            try:
                logger.info(f"Establishing DB connection (attempt {attempt}/{self.max_retries})")
                self._conn = mysql.connector.connect(
                    host=self._cfg["host"],
                    port=int(self._cfg.get("port", 3306)),
                    user=self._cfg["user"],
                    password=self._cfg["password"],
                    database=self._cfg["database"],
                    connection_timeout=10,
                    autocommit=True,
                )
                return self._conn
            except mysql.connector.Error as err:
                last_err = err
                logger.error(f"DB connect error: {err}")
                if attempt < self.max_retries:
                    time.sleep(self.retry_delay)

        raise last_err if last_err else RuntimeError("DB connect failed")

    def _query_one(self, sql: str, params: Optional[tuple] = None) -> Optional[tuple]:
        conn = self._connect()
        cur = conn.cursor(buffered=True)
        try:
            cur.execute(sql, params or ())
            return cur.fetchone()
        finally:
            try:
                cur.close()
            except Exception:
                pass

    def fetch_weather_data(self) -> Optional[WeatherData]:
        """Fetch latest values and aggregates from MySQL."""
        with self._lock:
            try:
                row = self._query_one(
                    """
                    SELECT
                        AIR_TEMP,
                        FEELS_LIKE,
                        PRESSURE_SEA,
                        HUMIDITY,
                        DEW_POINT,
                        UV_INDEX
                    FROM dataentry
                    ORDER BY id DESC
                    LIMIT 1;
                    """
                )
                if not row or row[0] is None:
                    logger.warning("No latest temperature data available")
                    return None

                air_temp, feels_like, pressure_sea, humidity, dew_point, uv_index = row
                uv = 0.0 if uv_index is None else float(uv_index)

                def scalar(sql: str) -> float:
                    r = self._query_one(sql)
                    if not r or r[0] is None:
                        return 0.0
                    try:
                        return float(r[0])
                    except Exception:
                        return 0.0

                # Your original windows
                wind_dir_2 = scalar(
                    "SELECT COALESCE(AVG(WIND_DIRECTION),0) FROM dataentry "
                    "WHERE CREATED BETWEEN DATE_ADD(NOW(), INTERVAL -2 MINUTE) AND NOW();"
                )
                wind_spd_2 = scalar(
                    "SELECT COALESCE(AVG(WIND_SPEED),0) FROM dataentry "
                    "WHERE CREATED BETWEEN DATE_ADD(NOW(), INTERVAL -2 MINUTE) AND NOW();"
                )

                wind_dir_5 = scalar(
                    "SELECT COALESCE(AVG(WIND_DIRECTION),0) FROM dataentry "
                    "WHERE CREATED BETWEEN DATE_ADD(NOW(), INTERVAL -5 MINUTE) AND NOW();"
                )
                wind_spd_5 = scalar(
                    "SELECT COALESCE(AVG(WIND_SPEED),0) FROM dataentry "
                    "WHERE CREATED BETWEEN DATE_ADD(NOW(), INTERVAL -5 MINUTE) AND NOW();"
                )
                wind_gst_5 = scalar(
                    "SELECT COALESCE(MAX(WIND_GUST),0) FROM dataentry "
                    "WHERE CREATED BETWEEN DATE_ADD(NOW(), INTERVAL -5 MINUTE) AND NOW();"
                )

                wind_spd_10 = scalar(
                    "SELECT COALESCE(AVG(WIND_SPEED),0) FROM dataentry "
                    "WHERE CREATED BETWEEN DATE_ADD(NOW(), INTERVAL -10 MINUTE) AND NOW();"
                )
                wind_gst_10 = scalar(
                    "SELECT COALESCE(MAX(WIND_GUST),0) FROM dataentry "
                    "WHERE CREATED BETWEEN DATE_ADD(NOW(), INTERVAL -10 MINUTE) AND NOW();"
                )
                wind_dir_10 = scalar(
                    "SELECT COALESCE(AVG(WIND_DIRECTION),0) FROM dataentry "
                    "WHERE CREATED BETWEEN DATE_ADD(NOW(), INTERVAL -10 MINUTE) AND NOW();"
                )

                daily_rain = scalar(
                    "SELECT COALESCE(SUM(RAINFALL),0) FROM dataentry "
                    "WHERE CREATED BETWEEN CURDATE() AND NOW();"
                )
                hourly_rain = scalar(
                    "SELECT COALESCE(SUM(RAINFALL),0) FROM dataentry "
                    "WHERE CREATED BETWEEN DATE_ADD(NOW(), INTERVAL -1 HOUR) AND NOW();"
                )

                wd = WeatherData(
                    timestamp=datetime.now(),

                    temperature_c=float(air_temp),
                    feels_like_c=float(feels_like),
                    pressure_sea_hpa=float(pressure_sea),
                    humidity_pct=float(humidity),
                    dew_point_c=float(dew_point),
                    uv_index=uv,

                    wind_dir_2min_deg=wind_dir_2,
                    wind_speed_2min_kmh=wind_spd_2,

                    wind_dir_5min_deg=wind_dir_5,
                    wind_speed_5min_kmh=wind_spd_5,
                    wind_gust_5min_kmh=wind_gst_5,

                    wind_dir_10min_deg=wind_dir_10,
                    wind_speed_10min_kmh=wind_spd_10,
                    wind_gust_10min_kmh=wind_gst_10,

                    daily_rain_mm=daily_rain,
                    hourly_rain_mm=hourly_rain,
                )

                logger.info(
                    "Retrieved weather data: "
                    f"Temp={wd.temperature_c}°C, Pressure={wd.pressure_sea_hpa} hPa, "
                    f"Humidity={wd.humidity_pct}%, Wind10={wd.wind_speed_10min_kmh} km/h @ {wd.wind_dir_10min_deg}°"
                )
                return wd

            except mysql.connector.Error as err:
                logger.error(f"Database error: {err}")
                try:
                    if self._conn is not None and self._conn.is_connected():
                        self._conn.close()
                except Exception:
                    pass
                self._conn = None
                return None
            except Exception as e:
                logger.error(f"Unexpected error retrieving weather data: {e}")
                logger.debug(traceback.format_exc())
                return None


# ----------------------------
# HTTP client with retries
# ----------------------------


class HttpClient:
    def __init__(self):
        self.session = requests.Session()

        retry = Retry(
            total=3,
            connect=3,
            read=3,
            backoff_factor=0.5,
            status_forcelist=(429, 500, 502, 503, 504),
            allowed_methods=("GET",),
            raise_on_status=False,
        )
        adapter = HTTPAdapter(max_retries=retry, pool_connections=10, pool_maxsize=10)
        self.session.mount("http://", adapter)
        self.session.mount("https://", adapter)

    def get(self, url: str, *, params: Optional[Dict[str, Any]] = None, timeout: int = 15) -> requests.Response:
        return self.session.get(url, params=params, timeout=timeout)


# ----------------------------
# Config loading/validation
# ----------------------------


REQUIRED_SERVICES = ("weathercloud", "wunderground", "windy", "pwsweather", "metoffice")


def load_config(path: str = "weather_services_config.yaml") -> Dict[str, Any]:
    try:
        with open(path, "r", encoding="utf-8") as f:
            cfg = yaml.safe_load(f) or {}
    except FileNotFoundError:
        # set up minimal console logging for this error
        logging.basicConfig(level=logging.INFO)
        logging.getLogger("WeatherStation").error(f"Configuration file '{path}' not found. Exiting.")
        sys.exit(1)
    except yaml.YAMLError as e:
        logging.basicConfig(level=logging.INFO)
        logging.getLogger("WeatherStation").error(f"Error parsing configuration file: {e}. Exiting.")
        sys.exit(1)
    except Exception as e:
        logging.basicConfig(level=logging.INFO)
        logging.getLogger("WeatherStation").error(f"Unexpected error loading configuration: {e}. Exiting.")
        sys.exit(1)

    if not validate_config(cfg):
        # configure logging enough to print the message
        logging.basicConfig(level=logging.INFO)
        logging.getLogger("WeatherStation").error("Configuration validation failed. Exiting.")
        sys.exit(1)
    return cfg


def validate_config(cfg: Dict[str, Any]) -> bool:
    if "services" not in cfg or not isinstance(cfg["services"], dict):
        print("Missing or invalid 'services' section in configuration file.")
        return False
    if "database" not in cfg or not isinstance(cfg["database"], dict):
        print("Missing or invalid 'database' section in configuration file.")
        return False

    db = cfg["database"]
    for k in ("host", "user", "password", "database"):
        if k not in db:
            print(f"Missing required database field: {k}")
            return False

    # port optional
    if "port" in db:
        try:
            int(db["port"])
        except Exception:
            print("Invalid database.port (must be an integer)")
            return False

    services = cfg["services"]
    for name in REQUIRED_SERVICES:
        if name not in services:
            print(f"Missing service configuration: {name}")
            return False
        sc = services[name]
        if "enabled" not in sc:
            print(f"Missing 'enabled' field for service: {name}")
            return False
        if "interval" not in sc:
            print(f"Missing 'interval' field for service: {name}")
            return False
        if "credentials" not in sc or not isinstance(sc["credentials"], dict):
            print(f"Missing/invalid 'credentials' for service: {name}")
            return False

        creds = sc["credentials"]
        if name == "weathercloud":
            for k in ("id", "key", "url"):
                if k not in creds:
                    print(f"Missing required Weathercloud credential: {k}")
                    return False
        elif name == "wunderground":
            for k in ("id", "password", "url"):
                if k not in creds:
                    print(f"Missing required Weather Underground credential: {k}")
                    return False
        elif name == "windy":
            if "url" not in creds:
                print("Missing required Windy credential: url")
                return False
        elif name == "pwsweather":
            for k in ("id", "password", "url", "software"):
                if k not in creds:
                    print(f"Missing required PWSWeather credential: {k}")
                    return False
        elif name == "metoffice":
            for k in ("siteid", "auth_key", "url", "software"):
                if k not in creds:
                    print(f"Missing required Met Office credential: {k}")
                    return False

    # logging optional
    if "logging" in cfg and not isinstance(cfg["logging"], dict):
        print("Invalid 'logging' section (must be a mapping)")
        return False

    return True


# ----------------------------
# Service base + implementations
# ----------------------------


class WeatherService:
    name: str

    def __init__(self, cfg: Dict[str, Any], http: HttpClient):
        self.cfg = cfg
        self.http = http

    @property
    def enabled(self) -> bool:
        return bool(self.cfg.get("enabled", False))

    @property
    def interval(self) -> int:
        try:
            return int(self.cfg.get("interval", 300))
        except Exception:
            return 300

    @property
    def credentials(self) -> Dict[str, Any]:
        return self.cfg.get("credentials", {})

    def send(self, data: WeatherData) -> bool:
        raise NotImplementedError


class WeathercloudService(WeatherService):
    name = "weathercloud"

    def send(self, data: WeatherData) -> bool:
        c = self.credentials
        logger.info("Preparing data for Weathercloud submission")

        params = {
            "wid": c["id"],
            "key": c["key"],
            "date": int(data.timestamp.timestamp()),
            "temp": int(data.temperature_c * 10),
            "hum": int(data.humidity_pct),
            "wdir": int(data.wind_dir_10min_deg),
            "wspd": int(kmh_to_ms_times10(data.wind_speed_10min_kmh)),
            "wgst": int(kmh_to_ms_times10(data.wind_gust_10min_kmh)),
            "bar": int(data.pressure_sea_hpa * 10),
            "rain": int(data.daily_rain_mm * 10),
            "uvi": int(data.uv_index * 10),
            "tempf": int(data.feels_like_c * 10),
        }

        try:
            r = self.http.get(c["url"], params=params, timeout=15)
            logger.info(f"Weathercloud update: {r.status_code} - {_now_str()}")
            if r.status_code != 200:
                logger.warning(f"Weathercloud non-200: {r.status_code}, response: {r.text}")
                return False
            logger.info("Successfully updated Weathercloud")
            return True
        except requests.RequestException as e:
            logger.error(f"Weathercloud update failed: {e}")
            return False
        except Exception as e:
            logger.error(f"Unexpected error updating Weathercloud: {e}")
            logger.debug(traceback.format_exc())
            return False


class WundergroundService(WeatherService):
    name = "wunderground"

    def send(self, data: WeatherData) -> bool:
        c = self.credentials
        logger.info("Preparing data for Weather Underground submission")

        dt = data.timestamp.strftime("%Y-%m-%d %H:%M:%S")
        params = {
            "ID": c["id"],
            "PASSWORD": c["password"],
            "dateutc": dt,
            "tempf": round(degc_to_degf(data.temperature_c), 1),
            "baromin": round(hpa_to_inches(data.pressure_sea_hpa), 2),
            "humidity": int(data.humidity_pct),
            "dewptf": round(degc_to_degf(data.dew_point_c), 1),
            "windspeedmph": round(kmh_to_mph(data.wind_speed_2min_kmh), 1),
            "windgustmph": round(kmh_to_mph(data.wind_gust_10min_kmh), 1),
            "winddir": int(data.wind_dir_2min_deg),
            "rainin": round(mm_to_inches(data.hourly_rain_mm), 2),
            "dailyrainin": round(mm_to_inches(data.daily_rain_mm), 2),
            "action": "updateraw",
        }

        try:
            r = self.http.get(c["url"], params=params, timeout=15)
            logger.info(f"Weather Underground update: {r.status_code} - {_now_str()}")
            if r.status_code != 200:
                logger.warning(f"Weather Underground non-200: {r.status_code}, response: {r.text}")
                return False
            logger.info("Successfully updated Weather Underground")
            return True
        except requests.RequestException as e:
            logger.error(f"Weather Underground update failed: {e}")
            return False
        except Exception as e:
            logger.error(f"Unexpected error updating Weather Underground: {e}")
            logger.debug(traceback.format_exc())
            return False


class WindyService(WeatherService):
    name = "windy"

    def send(self, data: WeatherData) -> bool:
        c = self.credentials
        logger.info("Preparing data for Windy submission")

        base_url = c["url"]

        params = {
            "temp": f"{data.temperature_c:.1f}",
            "uv": f"{data.uv_index:.1f}",
            "mbar": f"{data.pressure_sea_hpa:.1f}",
            "rh": f"{data.humidity_pct:.0f}",
            "dewpoint": f"{data.dew_point_c:.1f}",
            "precip": f"{data.hourly_rain_mm:.2f}",
            "windspeedmph": f"{kmh_to_mph(data.wind_speed_10min_kmh):.1f}",
            "windgustmph": f"{kmh_to_mph(data.wind_gust_10min_kmh):.1f}",
            "winddir": f"{data.wind_dir_10min_deg:.0f}",
        }

        try:
            url = build_url_with_params(base_url, params)
            r = self.http.get(url, params=None, timeout=15)
            logger.info(f"Windy update: {r.status_code} - {_now_str()}")
            if r.status_code != 200:
                logger.warning(f"Windy non-200: {r.status_code}, response: {r.text}")
                return False
            logger.info("Successfully updated Windy")
            return True
        except requests.RequestException as e:
            logger.error(f"Windy update failed: {e}")
            return False
        except Exception as e:
            logger.error(f"Unexpected error updating Windy: {e}")
            logger.debug(traceback.format_exc())
            return False


class PwsweatherService(WeatherService):
    name = "pwsweather"

    def send(self, data: WeatherData) -> bool:
        c = self.credentials
        logger.info("Preparing data for PWSWeather submission")

        dt = data.timestamp.strftime("%Y-%m-%d %H:%M:%S")
        params = {
            "ID": c["id"],
            "PASSWORD": c["password"],
            "dateutc": dt,
            "tempf": round(degc_to_degf(data.temperature_c), 1),
            "humidity": int(data.humidity_pct),
            "dewptf": round(degc_to_degf(data.dew_point_c), 1),
            "baromin": round(hpa_to_inches(data.pressure_sea_hpa), 2),
            "windspeedmph": round(kmh_to_mph(data.wind_speed_2min_kmh), 1),
            "windgustmph": round(kmh_to_mph(data.wind_gust_10min_kmh), 1),
            "winddir": int(data.wind_dir_2min_deg),
            "rainin": round(mm_to_inches(data.hourly_rain_mm), 2),
            "dailyrainin": round(mm_to_inches(data.daily_rain_mm), 2),
            "softwaretype": c["software"],
            "action": "updateraw",
        }

        try:
            r = self.http.get(c["url"], params=params, timeout=15)
            logger.info(f"PWSWeather update: {r.status_code} - {_now_str()}")
            if r.status_code != 200:
                logger.warning(f"PWSWeather non-200: {r.status_code}, response: {r.text}")
                return False
            logger.info("Successfully updated PWSWeather")
            return True
        except requests.RequestException as e:
            logger.error(f"PWSWeather update failed: {e}")
            return False
        except Exception as e:
            logger.error(f"Unexpected error updating PWSWeather: {e}")
            logger.debug(traceback.format_exc())
            return False


class MetOfficeService(WeatherService):
    name = "metoffice"

    def send(self, data: WeatherData) -> bool:
        c = self.credentials
        logger.info("Preparing data for Met Office submission")

        dt = data.timestamp.strftime("%Y-%m-%d %H:%M:%S")
        params = {
            "siteid": c["siteid"],
            "siteAuthenticationKey": c["auth_key"],
            "dateutc": dt,
            "tempf": round(degc_to_degf(data.temperature_c), 1),
            "humidity": int(data.humidity_pct),
            "dewptf": round(degc_to_degf(data.dew_point_c), 1),
            "baromin": round(hpa_to_inches(data.pressure_sea_hpa), 2),
            "windspeedmph": round(kmh_to_mph(data.wind_speed_10min_kmh), 1),
            "windgustmph": round(kmh_to_mph(data.wind_gust_10min_kmh), 1),
            "winddir": int(data.wind_dir_10min_deg),
            "rainin": round(mm_to_inches(data.hourly_rain_mm), 2),
            "UV": round(data.uv_index, 1),
            "softwaretype": c["software"],
        }

        try:
            r = self.http.get(c["url"], params=params, timeout=15)
            logger.info(f"Met Office update: {r.status_code} - {_now_str()}")
            if r.status_code != 200:
                logger.warning(f"Met Office non-200: {r.status_code}, response: {r.text}")
                return False
            logger.info("Successfully updated Met Office")
            return True
        except requests.RequestException as e:
            logger.error(f"Met Office update failed: {e}")
            return False
        except Exception as e:
            logger.error(f"Unexpected error updating Met Office: {e}")
            logger.debug(traceback.format_exc())
            return False


def build_services(services_cfg: Dict[str, Any], http: HttpClient) -> Dict[str, WeatherService]:
    return {
        "weathercloud": WeathercloudService(services_cfg["weathercloud"], http),
        "wunderground": WundergroundService(services_cfg["wunderground"], http),
        "windy": WindyService(services_cfg["windy"], http),
        "pwsweather": PwsweatherService(services_cfg["pwsweather"], http),
        "metoffice": MetOfficeService(services_cfg["metoffice"], http),
    }


# ----------------------------
# Runner / scheduling
# ----------------------------


def run_service_loop(svc: WeatherService, db: Database, *, stop_event: threading.Event) -> None:
    interval = max(10, int(svc.interval))
    jitter = min(5, max(1, interval // 20))

    logger.info(f"[{svc.name}] Runner starting (interval={interval}s, jitter≤{jitter}s)")

    next_run = time.time() + random.uniform(0, jitter)
    consecutive_failures = 0

    while not stop_event.is_set():
        try:
            sleep_time = max(0.0, next_run - time.time())
            if sleep_time > 0:
                stop_event.wait(timeout=sleep_time)
                if stop_event.is_set():
                    break

            logger.info(f"[{svc.name}] Retrieving weather data")
            data = db.fetch_weather_data()
            if data is None:
                logger.warning(f"[{svc.name}] No weather data available for update")
                consecutive_failures += 1
            else:
                ok = svc.send(data)
                if ok:
                    consecutive_failures = 0
                else:
                    consecutive_failures += 1

            next_run = time.time() + interval + random.uniform(0, jitter)
            next_update_time = datetime.fromtimestamp(next_run).strftime("%H:%M:%S")
            logger.info(f"[{svc.name}] Next update in ~{interval}s at {next_update_time}")

            if consecutive_failures > 0:
                backoff = min(30, 5 * consecutive_failures)
                logger.warning(f"[{svc.name}] Consecutive failures={consecutive_failures}, backoff={backoff}s")
                stop_event.wait(timeout=backoff)

        except Exception as e:
            logger.error(f"[{svc.name}] Error in service loop: {e}")
            logger.debug(traceback.format_exc())
            stop_event.wait(timeout=min(interval, 30))
            next_run = time.time() + interval

    logger.info(f"[{svc.name}] Runner stopped")


def start_service_threads(services: Dict[str, WeatherService], db: Database) -> Dict[str, Dict[str, Any]]:
    threads: Dict[str, Dict[str, Any]] = {}
    for name, svc in services.items():
        if not svc.enabled:
            logger.info(f"Service {name} is disabled in configuration")
            continue

        stop_event = threading.Event()
        t = threading.Thread(
            target=run_service_loop,
            args=(svc, db),
            kwargs={"stop_event": stop_event},
            name=f"{name}_thread",
            daemon=True,
        )
        t.start()
        threads[name] = {"thread": t, "stop": stop_event, "service": svc}
        logger.info(f"Started {name} service thread")
    return threads


def main() -> None:
    cfg = load_config("weather_services_config.yaml")
    setup_logging(cfg)

    logger.info("=== Weather Station Service Starting ===")

    db = Database(cfg["database"])

    # Validate DB connectivity early
    try:
        _ = db.fetch_weather_data()
        logger.info("Database connectivity check: OK")
    except Exception as e:
        logger.error(f"Failed to connect/query database: {e}")
        sys.exit(1)

    http = HttpClient()
    services = build_services(cfg["services"], http)
    threads = start_service_threads(services, db)

    if not threads:
        logger.warning("No services enabled. Exiting.")
        return

    logger.info("=== Weather Station Service Running ===")

    try:
        while True:
            alive = [name for name, meta in threads.items() if meta["thread"].is_alive()]
            logger.info(f"Service status: {len(alive)}/{len(threads)} active ({', '.join(alive)})")

            for name, meta in list(threads.items()):
                if not meta["thread"].is_alive():
                    logger.warning(f"Service {name} has stopped. Restarting...")
                    svc: WeatherService = meta["service"]
                    stop_event = threading.Event()
                    new_t = threading.Thread(
                        target=run_service_loop,
                        args=(svc, db),
                        kwargs={"stop_event": stop_event},
                        name=f"{name}_thread",
                        daemon=True,
                    )
                    new_t.start()
                    threads[name] = {"thread": new_t, "stop": stop_event, "service": svc}

            time.sleep(60)

    except KeyboardInterrupt:
        logger.info("Received shutdown signal. Exiting gracefully...")
        for meta in threads.values():
            meta["stop"].set()
        for meta in threads.values():
            meta["thread"].join(timeout=5)


if __name__ == "__main__":
    main()
